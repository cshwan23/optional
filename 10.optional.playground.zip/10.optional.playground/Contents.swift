import UIKit

//optional

//상수를 만들겁니다
let possibleNumber = "123"
let convertedNumber = Int(possibleNumber)

print(convertedNumber)
//옵셔널이라는 걸로 랩핑이 됩니다 => Optional(123)
//왜? 실제 값을 123이라고 넣엇기 때문에 이런데
//사용자들한테 값을 입력받아서 변환해야되는 경우가 있는데
//사용자들 숫자를 넣어야되는데 전화번호 안에 문자를 넣고 있는 경우가 많다

//optional의 정의가 그냥 값도 넣읋수 있고 닐값도 넣을 수 있다


if convertedNumber != nil {
    print(convertedNumber!)
}



//기본변수에다가 닐값을 넣을수있는지없는지 보여주겟다
var severResponseCode:Int? = 404
severResponseCode = nil


//optional 물음표를 달아서 표시할수있다.
//근데 문제는 런타임 돌아가다 죽는경우는 닐값일 경우가 많다.


//optional binding

if let actualNumber = Int(possibleNumber) {
    print(actualNumber)
}
